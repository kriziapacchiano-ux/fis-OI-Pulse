CSS="""
*{margin:0;padding:0;box-sizing:border-box}
body{background:#0A1A22;font-family:Inter,sans-serif;color:#E6EEF1}
.ex{width:1600px;padding:40px;display:grid;align-items:start;grid-template-columns:1010px 1fr;gap:28px;background:radial-gradient(1200px 700px at 0% 0%,#123240 0%,#0A1A22 60%),#0A1A22}
.win{background:#0D2530;border:1px solid #1E4351;border-radius:18px;overflow:hidden;display:flex;flex-direction:column}
.bar{display:flex;align-items:center;gap:10px;padding:16px 22px;border-bottom:1px solid #1E4351;background:#0F2B37}
.dots i{display:inline-block;width:10px;height:10px;border-radius:50%;background:#2C5564;margin-right:6px}
.app{font-weight:600;font-size:17px}.app small{font-family:'DejaVu Sans Mono';font-size:12px;letter-spacing:1.5px;color:#7F9AA4;margin-left:10px;text-transform:uppercase}
.pill{margin-left:auto;font-family:'DejaVu Sans Mono';font-size:12px;letter-spacing:1.5px;padding:6px 12px;border-radius:20px;border:1px solid}
.amber{color:#F2B33D;border-color:#6B5520}.green{color:#6BD66B;border-color:#2C6B33}.purple{color:#A996FF;border-color:#4A3E8A}
.body{padding:22px 26px;display:flex;flex-direction:column;gap:18px;flex:1}
.who{display:flex;align-items:center;gap:16px}
.av{width:52px;height:52px;border-radius:50%;background:#1E4351;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px;color:#BFD3DA}
.who h3{font-size:24px;font-weight:600}.who p{font-size:14px;color:#8FA8B0;margin-top:2px}
.kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.k{background:#0A1E27;border:1px solid #1E4351;border-radius:12px;padding:14px 16px}
.lab{font-family:'DejaVu Sans Mono';font-size:11.5px;letter-spacing:1.6px;color:#7F9AA4;text-transform:uppercase}
.k b{display:block;font-size:22px;margin-top:6px;font-weight:700}
.sec{font-family:'DejaVu Sans Mono';font-size:12px;letter-spacing:1.8px;color:#6BD66B;text-transform:uppercase}
.row{display:grid;grid-template-columns:1fr auto;gap:12px;align-items:center;background:#0A1E27;border-radius:10px;padding:11px 14px;font-size:15.5px}
.row span{font-family:'DejaVu Sans Mono';font-size:12px;color:#6BD66B}
.list{display:flex;flex-direction:column;gap:8px}
.meter{display:flex;align-items:center;gap:14px;font-size:15px}
.track{flex:1;height:10px;border-radius:6px;background:#173845;overflow:hidden}.track i{display:block;height:100%;border-radius:6px}
.act{border-left:4px solid #6BD66B;background:#0F2E2A;padding:14px 18px;border-radius:0 10px 10px 0;font-size:16px;line-height:1.5}
.btns{display:flex;gap:10px}.btn{font-family:'DejaVu Sans Mono';font-size:13px;letter-spacing:1.5px;padding:11px 16px;border-radius:8px;border:1px solid #2C5564;text-transform:uppercase}
.btn.p{background:#163F2A;border-color:#3D8F48;color:#8BE38B}
.side{display:flex;flex-direction:column;gap:20px}
.phone{align-self:center;width:330px;background:#07090F;border-radius:44px;padding:13px;border:2px solid #1E4351}
.scr{background:#F4F3FA;border-radius:33px;overflow:hidden;color:#1D1B2E;padding-bottom:16px}
.ph{background:#fff;padding:20px 18px 14px;text-align:center;border-top:4px solid #6E56E8}
.lg{width:38px;height:38px;border-radius:10px;background:#6E56E8;color:#fff;font-weight:700;display:inline-flex;align-items:center;justify-content:center}
.ph h4{font-size:17px;margin-top:8px;font-weight:600}.ph p{font-family:'DejaVu Sans Mono';font-size:10.5px;letter-spacing:1.5px;color:#6B6880;margin-top:2px}
.msg{margin:12px 14px 0;background:#fff;border:1px solid #E3E0F0;border-radius:16px;padding:12px 14px;font-size:14.5px;line-height:1.45}
.msg b{display:block;font-size:14.5px;margin-bottom:3px}
.chip{margin:8px 14px 0;border:1px solid #CFC6F7;background:#EEEAFE;color:#4A36B8;border-radius:20px;padding:8px 14px;font-size:13.5px}
.card{background:#0D2530;border:1px solid #1E4351;border-radius:14px;padding:16px 18px}
.card p{font-size:15px;line-height:1.45;margin-top:6px}
.log{display:flex;flex-direction:column;gap:7px;margin-top:10px}
.log div{display:grid;grid-template-columns:10px 1fr auto;gap:10px;align-items:center;font-size:13.5px;color:#C8D6DB}
.log i{width:8px;height:8px;border-radius:50%;background:#A996FF}.log i.g{background:#6BD66B}
.log span{font-family:'DejaVu Sans Mono';font-size:11.5px;color:#6F8A94}
.chart{display:flex;align-items:flex-end;gap:6px;height:170px;padding:10px 4px 0;border-bottom:1px solid #1E4351;position:relative}
.chart b{flex:1;border-radius:4px 4px 0 0}
"""
def kp(items): return '<div class="kpis">'+''.join(f'<div class="k"><div class="lab">{l}</div><b style="color:{c}">{v}</b></div>' for l,v,c in items)+'</div>'
def sig(items): return '<div class="list">'+''.join(f'<div class="row">{t}<span>{s}</span></div>' for t,s in items)+'</div>'
def meter(lab,pct,col,txt): return f'<div class="meter"><div style="width:230px">{lab}</div><div class="track"><i style="width:{pct}%;background:{col}"></i></div><b style="color:{col};width:90px;text-align:right">{txt}</b></div>'
def log(items): return '<div class="log">'+''.join(f'<div><i class="{g}"></i>{t}<span>{tm}</span></div>' for t,tm,g in items)+'</div>'
def phone(bank,sub,msgs,chips): 
    return f'<div class="phone"><div class="scr"><div class="ph"><div class="lg">B</div><h4>{bank}</h4><p>{sub}</p></div>'+''.join(f'<div class="msg">{m}</div>' for m in msgs)+''.join(f'<div class="chip">{c}</div>' for c in chips)+'</div></div>'
A=["#F2B33D","#6BD66B","#E6EEF1"]
ex=[]
# 1 Mortgage refinance
ex.append(f'''<div class="ex"><div class="win"><div class="bar"><span class="dots"><i></i><i></i><i></i></span><span class="app">Lending Concierge<small>Loan officer view</small></span><span class="pill amber">REFINANCE RISK · HIGH</span></div><div class="body">
<div class="who"><div class="av">MR</div><div><h3>Marcus &amp; Elena Reyes</h3><p>Customers 11 years · Checking · Savings · Mortgage</p></div></div>
{kp([("Mortgage rate","6.9%",A[0]),("Market rate today","5.8%",A[2]),("Likely to refinance away","72%",A[0])])}
<div class="sec">Why the agent flagged this</div>
{sig([("A payoff quote was requested by another lender","Lending"),("Viewed the refinance page 3 times this week","Digital"),("Rates dropped 1.1 pts since the loan was booked","Market"),("Always paid on time, strong savings balance","Core")])}
<div class="sec">Suggested next step</div>
<div class="act">Offer a rate review before they sign elsewhere. Pre-qualified at 5.9%, saving about $410 a month.</div>
<div class="btns"><span class="btn p">Send rate review</span><span class="btn">Schedule a call</span></div></div></div>
<div class="side">{phone("Your Bank","Home loans",["<b>You could lower your payment</b>Rates have dropped since you got your mortgage. You're pre-qualified for a rate review, no new application needed."],["See my new rate","Talk to my loan officer"])}
<div class="card"><div class="lab">Agent trail</div>{log([("Payoff request detected","08:12",""),("Refinance likelihood scored","08:12",""),("Rate pre-qualified within policy","08:14","g"),("Brief and customer offer sent","08:15","g")])}</div></div></div>''')
# 2 Early financial stress
ex.append(f'''<div class="ex"><div class="win"><div class="bar"><span class="dots"><i></i><i></i><i></i></span><span class="app">Customer Care<small>Early support queue</small></span><span class="pill purple">ACT BEFORE A MISSED PAYMENT</span></div><div class="body">
<div class="who"><div class="av">JT</div><div><h3>Jordan Taylor</h3><p>Customer 6 years · Checking · Credit card · Auto loan</p></div></div>
{kp([("Paycheck, last 2 months","−22%",A[0]),("Card balance trend","Rising",A[0]),("Chance of a missed payment","58%",A[0])])}
<div class="sec">What the agent sees</div>
{sig([("Direct deposit smaller for two pay cycles","Core"),("Overdraft used three times this month","Core"),("Card spend shifted to essentials","Cards"),("Auto payment due in 9 days","Lending")])}
<div class="sec">Suggested next step</div>
<div class="act">Offer to move the auto payment date to after payday, and share budgeting help. No fees, no collections call.</div>
<div class="btns"><span class="btn p">Send support offer</span><span class="btn">Assign to care team</span></div></div></div>
<div class="side">{phone("Your Bank","Here to help",["<b>A little more breathing room</b>Want to move your auto payment to the 18th, right after payday? It takes one tap and there's no fee."],["Move my payment date","Show me budgeting tips"])}
<div class="card"><div class="lab">Agent trail</div>{log([("Income change detected","Mon 07:40",""),("Missed-payment risk scored","Mon 07:41",""),("Hardship options checked against policy","Mon 07:41","g"),("Offer sent, care team notified","Mon 07:42","g")])}</div></div></div>''')
# 3 Commercial cash gap
bars=[(60,"#2C5564")]*0
hist=[62,58,64,60,66,63]; fc=[52,41,28,24,30,44]
chart='<div class="chart">'+''.join(f'<b style="height:{h}%;background:#2C6B7A"></b>' for h in hist)+''.join(f'<b style="height:{h}%;background:{"#F2B33D" if h<35 else "#4FA3B8"};opacity:.9"></b>' for h in fc)+'<div style="position:absolute;left:0;right:0;bottom:35%;border-top:2px dashed #F2B33D"></div></div>'
ex.append(f'''<div class="ex"><div class="win"><div class="bar"><span class="dots"><i></i><i></i><i></i></span><span class="app">Neural Treasury<small>Commercial client view</small></span><span class="pill amber">CASH GAP IN 3 WEEKS</span></div><div class="body">
<div class="who"><div class="av">NM</div><div><h3>Northline Manufacturing</h3><p>Commercial client · Operating account · Line of credit · Payroll</p></div></div>
{kp([("Forecast low point","$1.2M short",A[0]),("Expected date","Nov 2",A[2]),("Unused credit line","$3M",A[1])])}
<div class="sec">12-week cash forecast</div>
{chart}
<div style="display:flex;justify-content:space-between;font-family:DejaVu Sans Mono;font-size:11.5px;color:#7F9AA4"><span>LAST 6 WEEKS</span><span style="color:#F2B33D">MINIMUM CASH NEEDED</span><span>NEXT 6 WEEKS</span></div>
{sig([("Two large customers are paying 18 days later than usual","Payments"),("Quarterly tax payment and payroll land the same week","Core")])}
<div class="act">Suggest a short draw on the existing line, timed for Oct 30, and set up a sweep from the reserve account.</div>
<div class="btns"><span class="btn p">Share plan with CFO</span><span class="btn">Adjust forecast</span></div></div></div>
<div class="side"><div class="card"><div class="lab">Teams · Treasury management</div><p><b>Northline Manufacturing</b> may run short of cash around Nov 2. Plan ready in Neural Treasury for review.</p></div>
<div class="card"><div class="lab">Email · Northline CFO</div><p><b>Heads up on early November cash</b><br>Our forecast shows a dip below your minimum balance around Nov 2, driven by slower receivables. Your relationship manager has a plan ready to walk through.</p><div class="btns" style="margin-top:12px"><span class="btn p">Book 15 min</span><span class="btn">View forecast</span></div></div>
<div class="card"><div class="lab">Agent trail</div>{log([("Receivables delay detected","09:02",""),("Cash forecast rerun","09:03",""),("Credit line terms checked","09:04","g"),("RM and CFO notified","09:05","g")])}</div></div></div>''')
# 4 Wealth idle cash
ex.append(f'''<div class="ex"><div class="win"><div class="bar"><span class="dots"><i></i><i></i><i></i></span><span class="app">HORIZON 360<small>Advisor view</small></span><span class="pill green">OPPORTUNITY · CONTACT THIS WEEK</span></div><div class="body">
<div class="who"><div class="av">PS</div><div><h3>Priya Shah</h3><p>Customer 8 years · Checking · Savings · Credit card</p></div></div>
{kp([("New deposit","$480K",A[1]),("Sitting in checking","19 days",A[0]),("Likely to move it out","64%",A[0])])}
<div class="sec">What the agent sees</div>
{sig([("Large deposit from a home sale closing","Core"),("Opened an external brokerage link last week","Digital"),("No existing investment or wealth relationship","Core"),("Searching for a new mortgage in another city","Lending")])}
<div class="sec">Suggested next step</div>
<div class="act">Introduce a wealth advisor and a relocation mortgage review in one conversation. Priya prefers video calls in the evening.</div>
<div class="btns"><span class="btn p">Book advisor intro</span><span class="btn">Add to my week</span></div></div></div>
<div class="side">{phone("Your Bank","Wealth",["<b>Congratulations on your move</b>Planning what to do with the proceeds from your home sale? Meet an advisor and see mortgage options for your new city in one call."],["Book an evening video call","Maybe later"])}
<div class="card"><div class="lab">Agent trail</div>{log([("Large deposit detected","Tue 10:20",""),("Outflow likelihood scored","Tue 10:21",""),("Suitability and consent checked","Tue 10:21","g"),("Advisor brief and invite sent","Tue 10:23","g")])}</div></div></div>''')
open('ex.html','w').write('<html><head><meta charset="utf-8"><style>'+CSS+'</style></head><body>'+''.join(ex)+'</body></html>')
