# OI Pulse microsite: project brief

Context for continuing work on the OI Pulse microsite in a new account. Share this file with Claude, together with `site/index.html`, at the start of a new conversation.

## Changes since handoff (Oct 12, 2026)

- Customer 360 demo removed: not being explored. `ORDER = ['analytics','disputes']`; headings now say "Two banking moments, reimagined".
- "How it works" moved out of the Analytics pilot into the Why OI page (`#oi`) as a general section using FIS's OI slide copy (three cards plus five layers, 05 Activate to 01 Integrate). No product names per layer.
- The Analytics pilot now has two tabs: With vs. without, and What it could look like. The tables below describe the earlier state where they differ.

## The project

- **Client:** FIS. **Team:** Method. **Owner of this workstream:** Krizia (strategy).
- **Engagement:** FIS Innovation Hub 2026, an innovation roadshow that shows banks what Orchestrated Intelligence (OI) makes possible.
- **What the microsite is:** "OI Pulse", a clickable experience hub (low-fi coded concept, not live product UI). Structure modeled on the FIS Intelligence Hub, with an interactive with/without demo modeled on its "Agentic Commerce" demo.
- **Audience:** bank executives and FIS stakeholders. Many of these banks already use FIS.

## Writing rules (agreed)

- Measured, FIS-style tone. No hype, no superlatives ("the best", "revolutionary").
- Plain language. Avoid jargon such as "resolves", "read where they live", "next best action", "triggered", "governed".
- Don't over-summarize headlines; keep the meaning.
- Positive framing. Don't say "Without FIS": the audience already uses FIS. Contrast the capability: **Without / With Orchestrated Intelligence (OI)**.
- Avoid "bankers' calls" phrasing; use "client outreach" or "relationship teams / client teams".
- Don't call the CEO view a "cockpit"; it's the "Portfolio view" or "Portfolio strategy".
- Use existing FIS products only (list below).
- Lean slides: one idea per card, no stacked labels.

## Site structure (`site/index.html`)

Single static HTML file, no build step. Views are `<section class="view" id="v-…">`, toggled by `show()` and the URL hash.

| Hash | View | Contents |
|---|---|---|
| `#home` | Welcome | Hook: "See what changes when your systems…" |
| `#oi` | Why OI | FIS definition of OI, pillars, readiness tests |
| `#cranberries` | Demos | Demo tiles, order set by `ORDER = ['analytics','disputes','c360']` |
| `#disputes` | Disputes demo | "The best dispute is the one that never happens." |
| `#c360` | Customer 360 demo | "Knowing the customer isn't enough. Acting for them is." |
| `#analytics` | Predictive + Intelligent Analytics | Three tabs (below) |
| `#next` | Where to start | "Where would you start?" |

Older demos still defined in the `DEMOS` object but not shown in `ORDER`: `predictive` (earlier version), `fraud`, `cli`.

### Predictive + Intelligent Analytics view (`#v-analytics`)

- **Tab 1, With vs. without:** animated carousel (Start / Pause / Restart). Data lives in the JS array `ST` (stages: Detection, Insight, Outreach, Operations, Outcome). Uses the illustrative "Luna Café" story: a small business in Austin starts moving payroll to another bank.
- **Tab 2, How it works:** the five OI pyramid layers, animated bottom-up. Data lives in the JS array `LY`.
- **Tab 3, What it could look like:** a picker of five roles; each shows a large HTML mockup (`[data-sx]` buttons, `[data-sxv]` panels).
- Theme: light and dark mode via CSS tokens on `:root` (`--signal`, `--night`, `--plum`, `--line`, …). Fonts: Source Sans 3 (Google Fonts).

## The story

**Predictive + Intelligent Analytics** merged the earlier Predictive and Customer 360 ideas, following Kyle's feedback. It follows Jason's (FIS) five data experiences, each mapped to a role:

| Experience | Role |
|---|---|
| Future of BI & Reporting | Executives / CEO |
| Conversational Self-Serve | Leaders |
| Embedded Analytics | Relationship teams (client teams) |
| Proactive Alerting (Teams / email agent) | Customers |
| Agentic (AML / Disputes) | Back office |

### Latest with/without copy (lean version, from the deck)

**Title:** What changes for every role when data works together
**Subtitle:** Grey is today. Magenta is with Orchestrated Intelligence.

| Role | Today | With OI | Line |
|---|---|---|---|
| Executives | Reports explain last quarter | Early | See risk and growth in time to act |
| Leaders | Wait days for an analyst | Seconds | Ask anything, get the why |
| Client teams | Insights live in separate dashboards | Built in | The next step, inside the tools they use |
| Customers | Generic campaigns, sent too late | On time | Help that arrives as needs change |
| Back office | Manual reviews pile up | In context | Agents act with the full picture |

Alternative headlines considered: "Orchestrated Intelligence helps every part of the bank see what's coming"; "When data works together, the whole bank can look ahead".

### How it works: OI pyramid (FIS layer names and verbs)

Left-side cards:
- **From hindsight to foresight:** Instead of reporting what already happened, intelligence flags the trends and risks that matter while there's still time to act.
- **Answers, not dashboards:** Anyone can ask a question in plain language and get a clear answer, with the reasons behind it, in seconds.
- **Insight that moves:** Agents carry each insight to the people and systems that can act on it, from the boardroom to the branch.

| # | Layer | Verb | Description | Products |
|---|---|---|---|---|
| 05 | Activation via FIS ecosystem | Activate | Insights reach every role in the tools they already use, from leadership reports to banker screens and customer alerts. | HORIZON 360 · BIC · AgentEdge / IBS · Ethos Edge |
| 04 | Intelligence via models & agents | Amplify | AI models predict which customers may leave, where the risk is, and where to grow. | Analytic Solutions · Neural Treasury · Lending Concierge |
| 03 | AI governance & control plane | Govern | Checks consent, policy and model performance before anything moves, and logs every step. | (FIS product name to confirm) |
| 02 | AI-enabled unified data | Coordinate | Connects data from many systems into one trusted view of each customer. | FIS AI & Data Platform |
| 01 | Foundational data sources & infrastructure | Integrate | Brings together deposit, payment, card, lending and digital data from across FIS. | Core · Payments · Cards · Lending |

The microsite's How it works tab uses this copy.

### FIS products for this use case (from Jason)

Analytic Solutions · AgentEdge / IBS · HORIZON 360 / BIC (Business Intelligence) · Ethos Edge & Analytics · Neural Treasury · Lending Concierge (not Lending Sage).

FIS's own framing: "FIS already brings together data across 1.1B accounts and institutions, and agents extend that into connected actions." Highlighted functionality: AI-enabled BI tools, predictive dashboards, conversational data interfaces, leadership use cases (segment, portfolio performance, critical trends) and banker use cases (deposit attrition).

## Other examples of the same agent (screens in `reference-screens/`)

Same pattern every time: spot a signal → predict → check policy → route an action to each role.

1. **Mortgage refinance (Lending Concierge):** another lender requests a payoff quote and rates are down, so refinance risk is 72%. The loan officer gets a pre-qualified rate review; the customer gets "You could lower your payment".
2. **Early financial stress (Analytic Solutions · Ethos Edge):** smaller paychecks and more overdraft use mean a 58% chance of a missed payment. The customer is offered a fee-free payment-date move. Sensitive: show consent and policy clearly.
3. **Commercial cash gap (Neural Treasury):** late receivables plus tax and payroll in the same week mean $1.2M short around Nov 2. The treasury manager gets a plan, the CFO an email, the team a Teams alert.
4. **Wealth life event (HORIZON 360 · Analytic Solutions):** $480K from a home sale is idle and an external brokerage account was linked, so outflow risk is 64%. The advisor gets an intro brief; the customer an invite to an evening video call.

More ideas not built yet: card spend shifting to a competitor; first job or relocation; small-business growth ready for credit; branch and call-center staffing forecast.

## Caveats and open items

- **Figures:** 78% (FIS Digital One survey 2026), 96.7% (FIS Retail Banking Survey) and 1.1B accounts are FIS's own figures. Confirm external use.
- **Illustrative content:** Luna Café, $51M and all example customers and figures are made up.
- **Governance product:** "Control plane" is a placeholder. Get the real FIS product name for layer 03.
- **Screens:** only the CEO portfolio view is based on an FIS concept; the other mockups are illustrative.
- **Product mapping:** product-per-layer and product-per-experience mapping needs Jason's confirmation.
- **Signals in examples 1 and 4:** some signals (payoff requests, mortgage searches elsewhere) may not be data FIS has or may use.
- **Possible next steps:**
  - update Tab 1 to the general, lean with/without copy (it still tells the Luna Café story);
  - add a "Same agent, many moments" tab using the four example screens;
  - prototype the "CEO room" idea (brief → ask → rehearse → activate → learn).

## Publishing

- **Static hosting:** any static host works (GitHub Pages, Netlify, SharePoint). Upload `site/index.html`.
- **As a claude.ai Artifact in the new account:** ask Claude to publish `site/index.html` as an Artifact. Remove the first lines (`<!doctype html>`, `<html>`, `<head>` and the two `<meta>` tags) and the closing `</html>`, because the Artifact tool adds its own page skeleton.
- Keep it private until FIS confirms which figures can be shown.
