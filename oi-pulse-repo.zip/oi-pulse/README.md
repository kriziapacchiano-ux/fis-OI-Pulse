# OI Pulse microsite

Working draft of the OI Pulse experience hub for the FIS Innovation Hub roadshow (Method).

- `index.html`: the whole site in one file, no build step. Open it in a browser.
- `PROJECT-BRIEF.md`: story, agreed copy, tone rules and open items.
- `reference-screens/`: concept screens for other moments of the predictive agent.

All customer names and figures are illustrative. FIS survey figures need sign-off before external use. Keep this repository private until FIS confirms which figures can be shown.
